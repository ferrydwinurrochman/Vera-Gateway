'use client';

import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    apiKey: 'sk_live_51234567890abcdef',
    apiSecret: '••••••••••••••••',
    merchantId: 'MERCHANT_001',
    webhookUrl: 'https://example.com/webhook',
    isEnabled: true,
  });

  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground">
          Configure payment provider settings
        </p>
      </div>

      {/* Flypay Configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Provider - Flypay</CardTitle>
          <CardDescription>
            Configure your Flypay API credentials
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-3 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-900 rounded-lg">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm font-medium text-green-700 dark:text-green-300">
              Connected
            </span>
          </div>

          {/* API Key */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              API Key
            </label>
            <div className="flex gap-2">
              <Input
                type="password"
                value={settings.apiKey}
                readOnly
                className="font-mono text-xs"
              />
              <Button variant="outline" size="sm">
                View
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Keep your API key secret and never share it
            </p>
          </div>

          {/* Merchant ID */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Merchant ID
            </label>
            <Input
              value={settings.merchantId}
              readOnly
              className="font-mono text-sm"
            />
          </div>

          {/* Webhook URL */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Webhook URL
            </label>
            <Input
              type="url"
              value={settings.webhookUrl}
              readOnly
              className="font-mono text-sm"
            />
            <p className="text-xs text-muted-foreground">
              Flypay will send payment updates to this URL
            </p>
          </div>

          {/* Enable/Disable */}
          <div className="flex items-center justify-between p-3 border border-border rounded-lg">
            <div>
              <p className="font-medium text-foreground">Provider Status</p>
              <p className="text-sm text-muted-foreground">
                Enable or disable this payment provider
              </p>
            </div>
            <Badge className={settings.isEnabled ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'}>
              {settings.isEnabled ? 'Enabled' : 'Disabled'}
            </Badge>
          </div>

          <Button onClick={handleSave} className="w-full">
            {saved ? '✓ Saved' : 'Save Changes'}
          </Button>
        </CardContent>
      </Card>

      {/* Additional Settings */}
      <Card>
        <CardHeader>
          <CardTitle>System Settings</CardTitle>
          <CardDescription>
            General system configuration (UI placeholders)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Currency
            </label>
            <Input value="Indonesian Rupiah (IDR)" readOnly />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Timezone
            </label>
            <Input value="Asia/Jakarta" readOnly />
          </div>

          <Button variant="outline" className="w-full">
            Update System Settings
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
