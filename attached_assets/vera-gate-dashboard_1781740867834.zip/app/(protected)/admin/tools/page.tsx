'use client';

import React, { useState } from 'react';
import { Download, Trash2, AlertTriangle } from 'lucide-react';
import { mockTransactions } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function ToolsPage() {
  const [exported, setExported] = useState(false);

  const handleBulkExportCSV = () => {
    const headers = [
      'Reference ID',
      'Amount',
      'Status',
      'Payment Method',
      'Merchant ID',
      'Date',
    ];
    const csv = [
      headers.join(','),
      ...mockTransactions.map((tx) =>
        [
          tx.referenceId,
          tx.amount,
          tx.status,
          tx.paymentMethod,
          tx.merchantId,
          new Date(tx.createdAt).toISOString(),
        ].join(',')
      ),
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bulk-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  const handleBulkExportJSON = () => {
    const json = JSON.stringify(mockTransactions, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bulk-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    setExported(true);
    setTimeout(() => setExported(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Tools</h1>
        <p className="text-muted-foreground">System utilities and batch operations</p>
      </div>

      {/* Export Section */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Bulk Export
            </h2>
            <p className="text-sm text-muted-foreground">
              Export all transaction data in bulk
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div>
              <p className="text-sm font-medium text-foreground mb-2">
                Export as CSV
              </p>
              <Button
                onClick={handleBulkExportCSV}
                variant="outline"
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                {exported ? 'Exported!' : 'Export CSV'}
              </Button>
            </div>
            <div>
              <p className="text-sm font-medium text-foreground mb-2">
                Export as JSON
              </p>
              <Button
                onClick={handleBulkExportJSON}
                variant="outline"
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                {exported ? 'Exported!' : 'Export JSON'}
              </Button>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Total records: {mockTransactions.length}
          </p>
        </div>
      </div>

      {/* Dangerous Actions Section */}
      <div className="bg-card border border-destructive/30 rounded-lg p-6">
        <div className="flex items-start gap-3 mb-4">
          <AlertTriangle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
          <div>
            <h2 className="text-lg font-semibold text-foreground">
              Dangerous Actions
            </h2>
            <p className="text-sm text-muted-foreground">
              These actions cannot be undone
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="destructive"
                className="w-full md:w-auto"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Clear All Transactions
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear All Transactions?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. All transaction records will be
                  permanently deleted.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="flex gap-2">
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete
                </AlertDialogAction>
              </div>
            </AlertDialogContent>
          </AlertDialog>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="destructive"
                className="w-full md:w-auto"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Reset System
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Reset System?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will reset all system data to default values. This action
                  cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="flex gap-2">
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Reset
                </AlertDialogAction>
              </div>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}
