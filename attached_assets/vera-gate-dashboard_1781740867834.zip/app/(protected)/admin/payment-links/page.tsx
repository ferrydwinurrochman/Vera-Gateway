'use client';

import React, { useState } from 'react';
import { Plus, Copy, ExternalLink, Trash2 } from 'lucide-react';
import { mockPaymentLinks } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

export default function PaymentLinksPage() {
  const [links, setLinks] = useState(mockPaymentLinks);
  const [newLinkTitle, setNewLinkTitle] = useState('');
  const [newLinkAmount, setNewLinkAmount] = useState('');
  const [openDialog, setOpenDialog] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCreateLink = () => {
    if (!newLinkTitle.trim()) return;

    const newLink = {
      id: `link-${Date.now()}`,
      title: newLinkTitle,
      amount: newLinkAmount ? parseInt(newLinkAmount) : null,
      url: `https://veragate.example.com/pay/${Date.now()}`,
      status: 'active' as const,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
      clicks: 0,
    };

    setLinks([newLink, ...links]);
    setNewLinkTitle('');
    setNewLinkAmount('');
    setOpenDialog(false);
  };

  const handleCopyLink = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDeleteLink = (id: string) => {
    setLinks(links.filter((l) => l.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Payment Links</h1>
          <p className="text-muted-foreground">
            Create and manage payment links
          </p>
        </div>
        <Dialog open={openDialog} onOpenChange={setOpenDialog}>
          <DialogTrigger asChild>
            <Button size="sm" className="w-full md:w-auto">
              <Plus className="mr-2 h-4 w-4" />
              Create Link
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Payment Link</DialogTitle>
              <DialogDescription>
                Create a new payment link for your customers
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Title
                </label>
                <Input
                  placeholder="e.g., Monthly Subscription"
                  value={newLinkTitle}
                  onChange={(e) => setNewLinkTitle(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Amount (IDR) - Optional
                </label>
                <Input
                  placeholder="Leave empty for variable amount"
                  type="number"
                  value={newLinkAmount}
                  onChange={(e) => setNewLinkAmount(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={handleCreateLink}
                  className="flex-1"
                  disabled={!newLinkTitle.trim()}
                >
                  Create
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setOpenDialog(false)}
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Payment Links Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {links.length > 0 ? (
          links.map((link) => (
            <div
              key={link.id}
              className="bg-card border border-border rounded-lg p-4 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{link.title}</h3>
                  {link.amount && (
                    <p className="text-sm text-muted-foreground">
                      {new Intl.NumberFormat('id-ID', {
                        style: 'currency',
                        currency: 'IDR',
                      }).format(link.amount)}
                    </p>
                  )}
                </div>
                <Badge
                  variant="outline"
                  className={
                    link.status === 'active'
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
                  }
                >
                  {link.status}
                </Badge>
              </div>

              <div className="text-xs text-muted-foreground space-y-1">
                <p>Clicks: {link.clicks}</p>
                <p>
                  Expires:{' '}
                  {new Date(link.expiresAt).toLocaleDateString('id-ID')}
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => handleCopyLink(link.url, link.id)}
                >
                  {copiedId === link.id ? '✓ Copied' : 'Copy'}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  asChild
                >
                  <a href={link.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDeleteLink(link.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="text-muted-foreground">No payment links yet</p>
          </div>
        )}
      </div>
    </div>
  );
}
