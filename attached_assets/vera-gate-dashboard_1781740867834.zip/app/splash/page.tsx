'use client';

import React, { useState } from 'react';
import { ArrowRight, QrCode, Zap, Lock } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export default function SplashPage() {
  const [merchantName, setMerchantName] = useState('');
  const [amount, setAmount] = useState('');

  const handleCreateTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (merchantName && amount) {
      // In a real app, this would create a transaction and redirect to QRIS display
      const params = new URLSearchParams({
        merchant: merchantName,
        amount: amount,
      });
      window.location.href = `/qris?${params.toString()}`;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground text-sm font-bold">VG</span>
            </div>
            <h1 className="text-xl font-bold text-foreground">VERA GATE</h1>
          </div>
          <Link href="/login">
            <Button variant="outline" size="sm">
              Sign In
            </Button>
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 py-16 space-y-16">
        <section className="grid grid-cols-1 gap-8 items-center md:grid-cols-2">
          <div className="space-y-6">
            <div>
              <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
                Secure Payment Gateway
              </h2>
              <p className="text-lg text-muted-foreground">
                Fast, reliable, and secure payment processing for your business.
                Accept payments via QRIS, E-Wallet, and Bank Transfer.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="p-3 bg-card border border-border rounded-lg">
                <QrCode className="h-6 w-6 text-primary mb-2" />
                <p className="text-sm font-medium text-foreground">QRIS</p>
              </div>
              <div className="p-3 bg-card border border-border rounded-lg">
                <Zap className="h-6 w-6 text-primary mb-2" />
                <p className="text-sm font-medium text-foreground">E-Wallet</p>
              </div>
              <div className="p-3 bg-card border border-border rounded-lg">
                <Lock className="h-6 w-6 text-primary mb-2" />
                <p className="text-sm font-medium text-foreground">Bank</p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-8 space-y-6">
            <h3 className="text-2xl font-bold text-foreground">
              Create Payment Request
            </h3>

            <form onSubmit={handleCreateTransaction} className="space-y-4">
              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Merchant Name
                </label>
                <Input
                  placeholder="Your store name"
                  value={merchantName}
                  onChange={(e) => setMerchantName(e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="text-sm font-medium text-foreground block mb-2">
                  Amount (IDR)
                </label>
                <Input
                  type="number"
                  placeholder="100000"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                  min="10000"
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                size="lg"
                disabled={!merchantName || !amount}
              >
                Generate QRIS
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </form>

            <div className="pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground text-center">
                No account needed. Generate instant payment links.
              </p>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-12">
          <h3 className="text-3xl font-bold text-foreground mb-8 text-center">
            Why Choose VERA GATE?
          </h3>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            <div className="bg-card border border-border rounded-lg p-6 space-y-3">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground">Lightning Fast</h4>
              <p className="text-sm text-muted-foreground">
                Payments processed in milliseconds with instant confirmation.
              </p>
            </div>

            <div className="bg-card border border-border rounded-lg p-6 space-y-3">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <Lock className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground">Bank-Level Security</h4>
              <p className="text-sm text-muted-foreground">
                End-to-end encryption and PCI DSS compliance.
              </p>
            </div>

            <div className="bg-card border border-border rounded-lg p-6 space-y-3">
              <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                <QrCode className="h-6 w-6 text-primary" />
              </div>
              <h4 className="font-semibold text-foreground">Multiple Methods</h4>
              <p className="text-sm text-muted-foreground">
                QRIS, e-wallets, bank transfers, and more payment options.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>&copy; 2026 VERA GATE. All rights reserved.</p>
          <p className="mt-2">
            This is a frontend prototype with mock data for demonstration purposes.
          </p>
        </div>
      </footer>
    </div>
  );
}
