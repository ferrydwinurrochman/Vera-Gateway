'use client';

import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { QrCode, Copy, CheckCircle, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function QrisPage() {
  const searchParams = useSearchParams();
  const merchant = searchParams?.get('merchant') || 'Unknown Merchant';
  const amount = searchParams?.get('amount') || '0';
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes

  // Simulate QR code and countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatCurrency = (num: string) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
    }).format(parseInt(num));
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`Pay ${formatCurrency(amount)} at ${merchant}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isExpired = timeLeft === 0;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Header */}
        <div className="text-center">
          <div className="inline-block mb-4">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-primary-foreground text-lg font-bold">VG</span>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-foreground">Payment Request</h1>
        </div>

        {/* Main Card */}
        <div className="bg-card border border-border rounded-lg p-6 space-y-6">
          {/* Merchant Info */}
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Merchant</p>
            <p className="text-lg font-semibold text-foreground">{merchant}</p>
          </div>

          {/* Amount */}
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4 space-y-1">
            <p className="text-sm text-muted-foreground">Amount</p>
            <p className="text-3xl font-bold text-primary">
              {formatCurrency(amount)}
            </p>
          </div>

          {/* QR Code Section */}
          <div className="flex flex-col items-center gap-4 py-6 border-y border-border">
            <p className="text-sm font-medium text-foreground">Scan to Pay</p>

            {/* Mock QR Code */}
            <div className="w-64 h-64 bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border">
              <div className="text-center">
                <QrCode className="h-24 w-24 text-muted-foreground/50 mx-auto mb-2" />
                <p className="text-xs text-muted-foreground">
                  Mock QR Code
                </p>
              </div>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={handleCopy}
              className="w-full"
            >
              {copied ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Details
                </>
              )}
            </Button>
          </div>

          {/* Status */}
          <div className="flex items-start gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-900 rounded-lg">
            <Clock className="h-5 w-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-200">
                {isExpired ? 'Payment Expired' : 'Waiting for Payment'}
              </p>
              <p className="text-xs text-blue-700 dark:text-blue-300 mt-1">
                {isExpired
                  ? 'This payment request has expired'
                  : `Expires in ${formatTime(timeLeft)}`}
              </p>
            </div>
          </div>

          {/* Payment Methods Info */}
          <div className="space-y-2">
            <p className="text-sm font-medium text-foreground">
              Accepted Payment Methods
            </p>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="p-2 bg-muted rounded">
                <p className="font-medium">QRIS</p>
              </div>
              <div className="p-2 bg-muted rounded">
                <p className="font-medium">E-Wallet</p>
              </div>
              <div className="p-2 bg-muted rounded">
                <p className="font-medium">Bank</p>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-2">
            <Button variant="outline" className="w-full" disabled={isExpired}>
              {isExpired ? 'Payment Expired' : 'Check Status'}
            </Button>
            <Link href="/splash">
              <Button variant="ghost" className="w-full">
                Create Another Payment
              </Button>
            </Link>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-muted-foreground space-y-1">
          <p>Reference: REF-{new Date().getTime().toString().slice(-10)}</p>
          <p>
            This is a frontend prototype with mock payment data.
          </p>
        </div>
      </div>
    </div>
  );
}
