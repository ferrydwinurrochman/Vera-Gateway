'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Menu,
  X,
  LayoutDashboard,
  Link2,
  FileText,
  Wrench,
  Users,
  Store,
  Settings,
  LogOut,
  Moon,
  Sun,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { useTheme } from '@/lib/theme-provider';
import { Button } from '@/components/ui/button';

export function Sidebar() {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const { theme, setTheme, isDark } = useTheme();

  const isActive = (path: string) => pathname === path;

  const navigationItems = [
    {
      label: 'Dashboard',
      path: '/dashboard',
      icon: LayoutDashboard,
      public: false,
    },
  ];

  const adminItems = [
    {
      label: 'Payment Links',
      path: '/admin/payment-links',
      icon: Link2,
      admin: true,
    },
    {
      label: 'Reports',
      path: '/admin/reports',
      icon: FileText,
      admin: true,
    },
    {
      label: 'Tools',
      path: '/admin/tools',
      icon: Wrench,
      admin: true,
    },
    {
      label: 'Users',
      path: '/admin/users',
      icon: Users,
      admin: true,
    },
    {
      label: 'Merchants',
      path: '/admin/merchants',
      icon: Store,
      admin: true,
    },
    {
      label: 'Settings',
      path: '/admin/settings',
      icon: Settings,
      admin: true,
    },
  ];

  const visibleAdminItems =
    user?.role === 'admin'
      ? adminItems
      : adminItems.filter((item) => !item.admin);

  const allItems = [...navigationItems, ...visibleAdminItems];

  const handleLogout = () => {
    logout();
  };

  return (
    <>
      {/* Mobile menu button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden p-2 hover:bg-muted rounded-lg"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 h-screen w-64 bg-sidebar border-r border-sidebar-border transform transition-transform duration-200 z-40 lg:translate-x-0 flex flex-col ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo area */}
        <div className="p-6 border-b border-sidebar-border">
          <h1 className="text-2xl font-bold text-sidebar-primary">
            VERA GATE
          </h1>
          <p className="text-xs text-sidebar-foreground/60 mt-1">
            Payment Gateway
          </p>
        </div>

        {/* User info */}
        <div className="px-6 py-4 border-b border-sidebar-border">
          <p className="text-sm font-medium text-sidebar-foreground">
            {user?.name}
          </p>
          <p className="text-xs text-sidebar-foreground/60 capitalize">
            {user?.role}
          </p>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto p-4">
          <ul className="space-y-2">
            {allItems.map((item) => {
              const Icon = item.icon;
              return (
                <li key={item.path}>
                  <Link
                    href={item.path}
                    onClick={() => setIsOpen(false)}
                    className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${
                      isActive(item.path)
                        ? 'bg-sidebar-accent text-sidebar-accent-foreground'
                        : 'text-sidebar-foreground hover:bg-sidebar-accent/50'
                    }`}
                  >
                    <Icon size={18} />
                    <span className="text-sm font-medium">{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Dark mode toggle and logout */}
        <div className="p-4 border-t border-sidebar-border space-y-2">
          <Button
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            variant="outline"
            className="w-full flex items-center justify-center gap-2"
          >
            {isDark ? <Sun size={18} /> : <Moon size={18} />}
            <span>{isDark ? 'Light' : 'Dark'}</span>
          </Button>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full flex items-center justify-center gap-2"
          >
            <LogOut size={18} />
            <span>Logout</span>
          </Button>
        </div>
      </aside>

      {/* Main content offset */}
      <div className="lg:ml-64" />
    </>
  );
}
