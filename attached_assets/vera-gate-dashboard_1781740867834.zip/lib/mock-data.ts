// Mock data types and initial data for VERA GATE system
export type UserRole = 'admin' | 'operator';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: Date;
  lastLogin: Date;
}

export interface Transaction {
  id: string;
  referenceId: string;
  amount: number;
  paymentMethod: 'qris' | 'ewallet' | 'bank_transfer';
  status: 'pending' | 'success' | 'failed' | 'expired';
  merchantId: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  apiProvider: 'flypay' | 'other';
  description: string;
}

export interface Merchant {
  id: string;
  name: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive';
  createdAt: Date;
}

export interface PaymentLink {
  id: string;
  title: string;
  amount: number | null;
  url: string;
  status: 'active' | 'expired';
  createdAt: Date;
  expiresAt: Date;
  clicks: number;
}

// Mock users
export const mockUsers: User[] = [
  {
    id: 'user-1',
    email: 'admin@veragate.com',
    name: 'Admin User',
    role: 'admin',
    createdAt: new Date('2024-01-15'),
    lastLogin: new Date(),
  },
  {
    id: 'user-2',
    email: 'operator@veragate.com',
    name: 'Operator User',
    role: 'operator',
    createdAt: new Date('2024-02-01'),
    lastLogin: new Date('2026-06-17'),
  },
  {
    id: 'user-3',
    email: 'john@example.com',
    name: 'John Smith',
    role: 'operator',
    createdAt: new Date('2024-03-10'),
    lastLogin: new Date('2026-06-16'),
  },
];

// Mock transactions
export const mockTransactions: Transaction[] = [
  {
    id: 'tx-001',
    referenceId: 'REF-20260618-001',
    amount: 250000,
    paymentMethod: 'qris',
    status: 'success',
    merchantId: 'merchant-1',
    userId: 'user-1',
    createdAt: new Date('2026-06-18T10:30:00'),
    updatedAt: new Date('2026-06-18T10:35:00'),
    apiProvider: 'flypay',
    description: 'Payment for Order #12345',
  },
  {
    id: 'tx-002',
    referenceId: 'REF-20260618-002',
    amount: 500000,
    paymentMethod: 'ewallet',
    status: 'success',
    merchantId: 'merchant-2',
    userId: 'user-2',
    createdAt: new Date('2026-06-18T09:15:00'),
    updatedAt: new Date('2026-06-18T09:20:00'),
    apiProvider: 'flypay',
    description: 'Invoice #INV-2024-001',
  },
  {
    id: 'tx-003',
    referenceId: 'REF-20260618-003',
    amount: 100000,
    paymentMethod: 'bank_transfer',
    status: 'pending',
    merchantId: 'merchant-1',
    userId: 'user-1',
    createdAt: new Date('2026-06-18T08:00:00'),
    updatedAt: new Date('2026-06-18T08:00:00'),
    apiProvider: 'flypay',
    description: 'Subscription Payment',
  },
  {
    id: 'tx-004',
    referenceId: 'REF-20260617-004',
    amount: 750000,
    paymentMethod: 'qris',
    status: 'success',
    merchantId: 'merchant-3',
    userId: 'user-2',
    createdAt: new Date('2026-06-17T14:45:00'),
    updatedAt: new Date('2026-06-17T14:50:00'),
    apiProvider: 'flypay',
    description: 'B2B Payment',
  },
  {
    id: 'tx-005',
    referenceId: 'REF-20260617-005',
    amount: 125000,
    paymentMethod: 'ewallet',
    status: 'failed',
    merchantId: 'merchant-2',
    userId: 'user-1',
    createdAt: new Date('2026-06-17T11:20:00'),
    updatedAt: new Date('2026-06-17T11:25:00'),
    apiProvider: 'flypay',
    description: 'Refund Request',
  },
  {
    id: 'tx-006',
    referenceId: 'REF-20260617-006',
    amount: 300000,
    paymentMethod: 'qris',
    status: 'expired',
    merchantId: 'merchant-1',
    userId: 'user-2',
    createdAt: new Date('2026-06-17T07:30:00'),
    updatedAt: new Date('2026-06-17T09:30:00'),
    apiProvider: 'flypay',
    description: 'Checkout Payment',
  },
  {
    id: 'tx-007',
    referenceId: 'REF-20260616-007',
    amount: 450000,
    paymentMethod: 'bank_transfer',
    status: 'success',
    merchantId: 'merchant-3',
    userId: 'user-1',
    createdAt: new Date('2026-06-16T16:00:00'),
    updatedAt: new Date('2026-06-16T16:10:00'),
    apiProvider: 'flypay',
    description: 'Bulk Payment #7',
  },
];

// Mock merchants
export const mockMerchants: Merchant[] = [
  {
    id: 'merchant-1',
    name: 'PT Maju Jaya Indonesia',
    email: 'contact@majujaya.com',
    phone: '+62812345678',
    status: 'active',
    createdAt: new Date('2024-01-01'),
  },
  {
    id: 'merchant-2',
    name: 'CV Teknologi Digital',
    email: 'admin@teknodigital.com',
    phone: '+62823456789',
    status: 'active',
    createdAt: new Date('2024-01-15'),
  },
  {
    id: 'merchant-3',
    name: 'UD Retail Express',
    email: 'contact@retailexpress.com',
    phone: '+62834567890',
    status: 'inactive',
    createdAt: new Date('2024-02-10'),
  },
];

// Mock payment links
export const mockPaymentLinks: PaymentLink[] = [
  {
    id: 'link-1',
    title: 'Service Subscription - Monthly',
    amount: 99000,
    url: 'https://veragate.example.com/pay/link-1',
    status: 'active',
    createdAt: new Date('2026-06-15'),
    expiresAt: new Date('2026-12-31'),
    clicks: 145,
  },
  {
    id: 'link-2',
    title: 'Product Purchase - Bundle',
    amount: null,
    url: 'https://veragate.example.com/pay/link-2',
    status: 'active',
    createdAt: new Date('2026-06-14'),
    expiresAt: new Date('2026-07-14'),
    clicks: 312,
  },
  {
    id: 'link-3',
    title: 'Event Registration',
    amount: 250000,
    url: 'https://veragate.example.com/pay/link-3',
    status: 'expired',
    createdAt: new Date('2026-05-01'),
    expiresAt: new Date('2026-06-01'),
    clicks: 89,
  },
];
