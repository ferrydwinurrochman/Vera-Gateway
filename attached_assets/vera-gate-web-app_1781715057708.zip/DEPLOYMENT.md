# Deployment Guide - VERA GATE

This guide covers how to deploy VERA GATE to various platforms.

## 🚀 Quick Deploy to Vercel (Recommended)

VERA GATE is optimized for Vercel deployment with Next.js 16 support.

### Option 1: Deploy via Git
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "New Project"
4. Import your GitHub repository
5. Vercel will auto-detect Next.js
6. Click "Deploy"

### Option 2: Deploy via CLI
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

## 🐳 Docker Deployment

### Dockerfile
```dockerfile
FROM node:18-alpine AS deps
WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install --frozen-lockfile

FROM node:18-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm install -g pnpm && pnpm build

FROM node:18-alpine AS runner
WORKDIR /app
RUN addgroup -g 1001 -S nodejs && adduser -S nextjs -u 1001
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json ./package.json
USER nextjs
EXPOSE 3000
CMD ["npm", "start"]
```

### Build and Run
```bash
# Build
docker build -t vera-gate .

# Run
docker run -p 3000:3000 vera-gate
```

## 📦 AWS Deployment

### Using AWS Amplify
1. Connect your GitHub repository
2. Select "Next.js" framework
3. Configure build settings:
   - Build command: `pnpm build`
   - Start command: `pnpm start`
4. Deploy

### Using AWS EC2
1. Launch an Ubuntu EC2 instance
2. SSH into the instance
3. Install Node.js 18+
4. Clone the repository
5. Run:
   ```bash
   pnpm install
   pnpm build
   pnpm start
   ```

## 🌐 Other Platforms

### Netlify
- Connect your Git repository
- Build command: `pnpm build`
- Publish directory: `.next`
- Deploy

### GitHub Pages (Static Export)
1. Update `next.config.mjs`:
   ```js
   export default {
     output: 'export',
   }
   ```
2. Build: `pnpm build`
3. Deploy to GitHub Pages

## 🔐 Environment Variables

Set these environment variables on your deployment platform:

```env
# Node environment
NODE_ENV=production

# Optional: Analytics
NEXT_PUBLIC_APP_NAME=VERA GATE
NEXT_PUBLIC_API_URL=https://your-api.com
```

## 📊 Performance Optimization

### CDN Configuration
- Enable Vercel Edge Network (automatic with Vercel)
- Set Cache-Control headers for static assets
- Use image optimization

### Monitoring
- Enable [Vercel Analytics](https://vercel.com/analytics)
- Monitor Core Web Vitals
- Set up error tracking

## 🔄 CI/CD Pipeline

### GitHub Actions Example
```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: pnpm/action-setup@v2
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'pnpm'
      - run: pnpm install
      - run: pnpm build
      - run: pnpm lint
      # Deploy to your platform here
```

## ✅ Pre-Deployment Checklist

- [ ] All tests passing
- [ ] ESLint checks passed
- [ ] Environment variables configured
- [ ] Build completes without errors
- [ ] Preview deployment reviewed
- [ ] Analytics enabled
- [ ] Error tracking configured
- [ ] HTTPS enabled
- [ ] Security headers configured
- [ ] Monitoring alerts set up

## 🚨 Troubleshooting

### Build Fails
- Clear `.next` directory: `rm -rf .next`
- Reinstall dependencies: `rm -rf node_modules pnpm-lock.yaml && pnpm install`
- Check Node.js version: `node --version` (should be 18+)

### Performance Issues
- Enable caching: `pnpm build --cache`
- Check bundle size: `pnpm build --analyze`
- Monitor Web Vitals

### Deployment Issues
- Check logs on your deployment platform
- Verify environment variables are set correctly
- Test locally first: `pnpm build && pnpm start`

## 📞 Support

For deployment issues:
1. Check [Next.js Deployment Docs](https://nextjs.org/docs/deployment)
2. Review [Vercel Docs](https://vercel.com/docs)
3. Open an issue on GitHub

---

**Last Updated**: June 17, 2026
