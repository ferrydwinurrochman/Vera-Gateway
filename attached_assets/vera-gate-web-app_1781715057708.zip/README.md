# VERA GATE - Modern Payment Gateway Dashboard

A modern, secure payment gateway dashboard built with **Next.js 16**, **React 19**, and **Tailwind CSS**. Inspired by the original PHP project but completely redesigned with a contemporary dark theme and sleek UI/UX.

![VERA GATE Dashboard](./public/vera-logo.png)

## 📋 Project Overview

VERA GATE is a **monorepo web application** that provides:

- 💳 **Modern Payment Dashboard** - Real-time transaction monitoring and analytics
- 🔐 **Security-First Design** - Enterprise-grade security with visual trust indicators
- 📊 **Advanced Analytics** - Revenue trends, performance metrics, and quick stats
- 🎨 **Dark Mode by Default** - Modern dark theme with professional blue accent colors
- 📱 **Fully Responsive** - Optimized for desktop, tablet, and mobile devices
- ⚡ **Fast & Lightweight** - Built with Next.js 16 and Turbopack for optimal performance
- 🧩 **Component-Based** - Modular architecture with reusable UI components

## 🚀 Features

### Dashboard Features
- **Welcome Section** - Personalized greeting with performance status
- **Key Metrics** - Total balance, today's transactions, pending payouts, active merchants
- **Revenue Trend Chart** - 7-day performance visualization with interactive bars
- **Quick Stats** - Success rate, response time, uptime, active users
- **Recent Transactions** - Live transaction history with status indicators
- **Sidebar Navigation** - Collapsible menu with all major sections
- **Notification Center** - Real-time alerts and updates

### Navigation Sections
- **Dashboard** - Main overview with all key metrics
- **Transactions** - Detailed transaction history and filters
- **Send Money** - Quick money transfer interface
- **Withdraw** - Withdrawal request management
- **Merchants** - Merchant account management
- **Tools** - CSV/JSON export, reports, utilities
- **Settings** - Configuration and preferences

## 🛠 Tech Stack

- **Framework**: [Next.js 16](https://nextjs.org/) with App Router
- **Language**: [TypeScript](https://www.typescriptlang.org/)
- **Styling**: [Tailwind CSS v4](https://tailwindcss.com/)
- **Component Library**: [shadcn/ui](https://ui.shadcn.com/)
- **Icons**: [Lucide React](https://lucide.dev/)
- **Build Tool**: [Turbopack](https://turbo.build/pack)
- **Package Manager**: [pnpm](https://pnpm.io/)
- **Monorepo**: [Turbo](https://turbo.build/)

## 📁 Project Structure

```
vera-gate-monorepo/
├── app/
│   ├── layout.tsx              # Root layout with dark theme
│   ├── globals.css             # Global styles and theme tokens
│   ├── page.tsx                # Root page (redirects to dashboard)
│   ├── dashboard/
│   │   └── page.tsx            # Main dashboard page
│   └── landing.tsx             # Landing page (future use)
├── components/
│   └── ui/                     # shadcn/ui components
├── public/
│   └── vera-logo.png           # Logo and assets
├── lib/
│   └── utils.ts                # Utility functions
├── package.json                # Project dependencies
├── tsconfig.json               # TypeScript configuration
├── next.config.mjs             # Next.js configuration
└── tailwind.config.js          # Tailwind CSS configuration
```

## 🎨 Design System

### Color Palette
- **Primary**: `#0066cc` (Blue) - Main action color
- **Accent**: `#00a4ef` (Cyan) - Highlights and accents
- **Background**: `#0f1419` (Dark Navy) - Primary background
- **Card**: `#1a1f2e` (Darker Navy) - Card backgrounds
- **Border**: `#2a2f3e` (Gray) - Borders and dividers
- **Success**: `#10b981` (Green) - Success states
- **Warning**: `#f59e0b` (Amber) - Warning states
- **Danger**: `#ef4444` (Red) - Error states

### Typography
- **Font**: Geist (sans-serif) for UI
- **Mono**: Geist Mono for code and technical text
- **Heading Scale**: 12px → 56px with proper hierarchy

## 🚀 Getting Started

### Prerequisites
- Node.js 18.0.0 or higher
- pnpm (recommended) or npm/yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd vera-gate-monorepo
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Start the development server**
   ```bash
   pnpm dev
   ```

4. **Open in browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Available Scripts

```bash
# Development
pnpm dev              # Start dev server with HMR

# Production
pnpm build            # Build for production
pnpm start            # Start production server

# Code Quality
pnpm lint             # Run ESLint
```

## 🔧 Environment Setup

Create a `.env.local` file for environment-specific configuration:

```env
# Example environment variables
NEXT_PUBLIC_APP_NAME=VERA GATE
NEXT_PUBLIC_API_URL=https://api.vera-gate.com
```

## 📊 Dashboard Metrics

### Real-Time Data
- **Total Balance**: Account balance with trend indicator
- **Today Transactions**: Daily transaction count and growth
- **Pending Payouts**: Number of pending withdrawal requests
- **Active Merchants**: Count of active merchant accounts

### Performance Stats
- **Success Rate**: Payment success percentage
- **Avg. Response**: Average API response time
- **Uptime**: System uptime percentage
- **Active Users**: Number of concurrent users

## 🌙 Dark Mode

The application uses a dark theme by default with semantic color tokens:

```css
/* CSS Variables */
--background: #0f1419
--foreground: #e4e7eb
--primary: #0066cc
--accent: #00a4ef
--card: #1a1f2e
--border: #2a2f3e
```

## 🔐 Security Features

- Enterprise-grade data encryption
- PCI DSS compliance
- Session management
- CSRF protection
- Input validation
- Secure headers

## 📈 Performance Optimizations

- Next.js 16 with Turbopack (3x faster builds)
- Code splitting and lazy loading
- Image optimization
- CSS optimization with Tailwind v4
- React Server Components where applicable

## 🎯 Future Enhancements

- [ ] Backend API integration
- [ ] Real-time WebSocket updates
- [ ] Advanced filters and search
- [ ] Custom report generation
- [ ] User authentication
- [ ] Role-based access control
- [ ] Multi-language support
- [ ] Mobile app (React Native)

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support, email support@vera-gate.com or open an issue on the repository.

## 🙏 Acknowledgments

- Inspired by the original VERA GATE PHP project
- Built with [Next.js](https://nextjs.org/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)
- Icons from [Lucide React](https://lucide.dev/)

---

**Version**: 1.0.0  
**Last Updated**: June 17, 2026  
**Status**: 🟢 Active Development
