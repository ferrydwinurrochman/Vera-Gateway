'use client'

import { useState } from 'react'
import {
  CreditCard,
  BarChart3,
  Settings,
  LogOut,
  Menu,
  Link2,
  FileText,
  Zap,
  Users,
  Building2,
  Cog,
  Trash2,
  Bell,
  Edit,
  Plus,
  Download,
  Eye,
  Copy,
  ArrowRight,
} from 'lucide-react'

export default function DashboardPage() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [activeTab, setActiveTab] = useState('dashboard')

  // Content for each tab
  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />
      case 'payment-link':
        return <PaymentLinkView />
      case 'report':
        return <ReportView />
      case 'tools':
        return <ToolsView />
      case 'users':
        return <UsersView />
      case 'merchant':
        return <MerchantView />
      case 'provider':
        return <ProviderView />
      default:
        return <DashboardView />
    }
  }

  const navItems = [
    { icon: BarChart3, label: 'Dashboard', id: 'dashboard' },
    { icon: Link2, label: 'Payment Link', id: 'payment-link' },
    { icon: FileText, label: 'Report', id: 'report' },
    { icon: Zap, label: 'Tools', id: 'tools', admin: true },
    { icon: Users, label: 'User Management', id: 'users', admin: true },
    { icon: Building2, label: 'Merchant', id: 'merchant', admin: true },
    { icon: Cog, label: 'Pengaturan Provider', id: 'provider', admin: true },
  ]

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-40 h-screen bg-card border-r border-border transition-all duration-300 ${
          sidebarOpen ? 'w-64' : 'w-20'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between px-4 py-6 border-b border-border">
            {sidebarOpen && (
              <div>
                <h1 className="text-lg font-bold text-primary">VERA GATE</h1>
                <p className="text-xs text-muted-foreground">PAYMENT GATEWAY</p>
              </div>
            )}
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>

          {/* Merchant Info */}
          {sidebarOpen && (
            <div className="mx-4 my-4 px-3 py-3 bg-primary/10 border border-primary/30 rounded-lg">
              <p className="text-xs text-muted-foreground font-semibold">Merchant</p>
              <p className="font-bold text-primary">VERA GATE</p>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-2">
            {navItems.map(({ icon: Icon, label, id, admin }) => (
              <div key={id}>
                {admin && id === 'tools' && sidebarOpen && (
                  <div className="px-3 py-2 text-xs font-bold text-muted-foreground uppercase mt-3 mb-1">
                    Admin
                  </div>
                )}
                <button
                  onClick={() => setActiveTab(id)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 ${
                    activeTab === id
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  }`}
                >
                  <Icon className="w-5 h-5 flex-shrink-0" />
                  {sidebarOpen && <span className="text-sm font-medium">{label}</span>}
                </button>
              </div>
            ))}
          </nav>

          {/* Footer */}
          <div className="border-t border-border p-3 text-xs text-muted-foreground space-y-2">
            {sidebarOpen && (
              <div className="px-2">
                <p className="font-semibold">Version 1.0</p>
                <p>Asia/Jakarta</p>
              </div>
            )}
            <button className="w-full flex items-center gap-3 px-3 py-2 text-destructive hover:bg-destructive/10 rounded-lg transition-colors font-medium">
              <LogOut className="w-4 h-4 flex-shrink-0" />
              {sidebarOpen && <span className="text-sm">Logout</span>}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-20'}`}>
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-card border-b border-border">
          <div className="px-6 py-4 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-foreground">
              {navItems.find((i) => i.id === activeTab)?.label || 'Dashboard'}
            </h2>
            <div className="flex items-center gap-4">
              <button className="relative p-2 hover:bg-muted rounded-lg transition-colors">
                <Bell className="w-5 h-5 text-muted-foreground" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full" />
              </button>
              <span className="px-3 py-1 bg-primary text-primary-foreground text-xs font-bold rounded-full">
                PRODUCTION
              </span>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="p-6">{renderContent()}</div>
      </main>
    </div>
  )
}

// Dashboard View
function DashboardView() {
  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Balance', value: 'Rp 24.580.500' },
          { label: 'Today Transactions', value: '1,248' },
          { label: 'Pending Status', value: '15' },
          { label: 'Active Users', value: '42' },
        ].map((stat, i) => (
          <div key={i} className="bg-card border border-border rounded-lg p-4">
            <p className="text-muted-foreground text-sm mb-2">{stat.label}</p>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Transactions Table */}
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="mb-4">
          <h3 className="text-lg font-bold text-foreground">Recent Transactions</h3>
          <p className="text-sm text-muted-foreground">Latest activity from your account</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Ref No</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Username</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Nominal</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Method</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Date</th>
              </tr>
            </thead>
            <tbody>
              {[
                { ref: 'TXN001', user: 'budi_santoso', nominal: 'Rp 500.000', method: 'QRIS', status: 'Sukses', date: '2024-06-17' },
                { ref: 'TXN002', user: 'john_doe', nominal: 'Rp 250.000', method: 'Bank Transfer', status: 'Menunggu', date: '2024-06-17' },
                { ref: 'TXN003', user: 'siti_aminah', nominal: 'Rp 1.000.000', method: 'QRIS', status: 'Sukses', date: '2024-06-16' },
              ].map((row, i) => (
                <tr key={i} className="border-b border-border hover:bg-muted/50 transition-colors">
                  <td className="py-3 px-4 text-foreground font-mono text-xs">{row.ref}</td>
                  <td className="py-3 px-4 text-foreground">{row.user}</td>
                  <td className="py-3 px-4 text-foreground font-mono">{row.nominal}</td>
                  <td className="py-3 px-4 text-foreground">{row.method}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-1 rounded text-xs font-bold ${
                        row.status === 'Sukses'
                          ? 'bg-green-500/20 text-green-400'
                          : 'bg-yellow-500/20 text-yellow-400'
                      }`}
                    >
                      {row.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-muted-foreground text-xs">{row.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Payment Link View
function PaymentLinkView() {
  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <button className="btn-primary gap-2">
          <Plus className="w-5 h-5" />
          Create Payment Link
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-bold text-foreground mb-4">Payment Links</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Link ID</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Amount</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Created</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-border hover:bg-muted/50">
                <td className="py-3 px-4 text-foreground">LINK001</td>
                <td className="py-3 px-4 text-foreground font-mono">Rp 1.000.000</td>
                <td className="py-3 px-4 text-muted-foreground">2024-06-15</td>
                <td className="py-3 px-4">
                  <span className="px-2 py-1 rounded text-xs font-bold bg-blue-500/20 text-blue-400">Active</span>
                </td>
                <td className="py-3 px-4 flex gap-2">
                  <button className="btn-action">
                    <Copy className="w-4 h-4" />
                  </button>
                  <button className="btn-action">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button className="btn-action delete">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Report View
function ReportView() {
  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <button className="btn-primary gap-2">
          <Download className="w-5 h-5" />
          Export to PDF
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-bold text-foreground mb-2">Transaction Report</h3>
        <p className="text-sm text-muted-foreground mb-4">Generate and download transaction reports in PDF format</p>
        <p className="text-sm text-muted-foreground">Select date range and filters to generate your report.</p>
      </div>
    </div>
  )
}

// Tools View
function ToolsView() {
  return (
    <div className="space-y-6">
      <h3 className="text-lg font-bold text-foreground">Export Tools</h3>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-bold text-foreground mb-2">Export CSV</h4>
          <p className="text-sm text-muted-foreground mb-4">Export all transactions as CSV file</p>
          <button className="btn-primary w-full">Export CSV</button>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-bold text-foreground mb-2">Export JSON</h4>
          <p className="text-sm text-muted-foreground mb-4">Export all transactions as JSON file</p>
          <button className="btn-primary w-full">Export JSON</button>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <h4 className="font-bold text-foreground mb-2">Reset Transactions</h4>
          <p className="text-sm text-muted-foreground mb-4">Clear all transaction data (WARNING)</p>
          <button className="btn-danger w-full">Reset All</button>
        </div>
      </div>
    </div>
  )
}

// Users View
function UsersView() {
  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <button className="btn-primary gap-2">
          <Plus className="w-5 h-5" />
          Add User
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-bold text-foreground mb-4">User Management</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Name</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Email</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Role</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Admin User', email: 'admin@vera.gate', role: 'Admin', status: 'Active' },
                { name: 'Operator', email: 'operator@vera.gate', role: 'Operator', status: 'Active' },
              ].map((user, i) => (
                <tr key={i} className="border-b border-border hover:bg-muted/50">
                  <td className="py-3 px-4 text-foreground">{user.name}</td>
                  <td className="py-3 px-4 text-foreground">{user.email}</td>
                  <td className="py-3 px-4 text-foreground">{user.role}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-1 rounded text-xs font-bold bg-green-500/20 text-green-400">
                      {user.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <button className="btn-action">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="btn-action delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Merchant View
function MerchantView() {
  return (
    <div className="space-y-6">
      <div className="flex gap-3">
        <button className="btn-primary gap-2">
          <Plus className="w-5 h-5" />
          Add Merchant
        </button>
      </div>

      <div className="bg-card border border-border rounded-lg p-6">
        <h3 className="text-lg font-bold text-foreground mb-4">Merchant Management</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Merchant Name</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Code</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">API Key</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Status</th>
                <th className="text-left py-3 px-4 font-bold text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Merchant 1', code: 'M1', key: 'key_xxxx...', status: 'Active' },
                { name: 'Merchant 2', code: 'M2', key: 'key_yyyy...', status: 'Active' },
              ].map((merchant, i) => (
                <tr key={i} className="border-b border-border hover:bg-muted/50">
                  <td className="py-3 px-4 text-foreground">{merchant.name}</td>
                  <td className="py-3 px-4 text-foreground font-mono">{merchant.code}</td>
                  <td className="py-3 px-4 text-muted-foreground text-xs">{merchant.key}</td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-1 rounded text-xs font-bold bg-green-500/20 text-green-400">
                      {merchant.status}
                    </span>
                  </td>
                  <td className="py-3 px-4 flex gap-2">
                    <button className="btn-action">
                      <Edit className="w-4 h-4" />
                    </button>
                    <button className="btn-action delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Provider View
function ProviderView() {
  return (
    <div className="space-y-6">
      <div className="bg-card border border-border rounded-lg p-6 max-w-2xl">
        <h3 className="text-lg font-bold text-foreground mb-4">Flypay Settings</h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-foreground mb-2">App ID</label>
            <input
              type="text"
              placeholder="Your Flypay App ID"
              className="w-full bg-input border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              defaultValue="4183"
            />
          </div>

          <div>
            <label className="block text-sm font-bold text-foreground mb-2">Secret Key</label>
            <input
              type="password"
              placeholder="Your Flypay Secret Key"
              className="w-full bg-input border border-border rounded-lg px-4 py-2 text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
              defaultValue="XEsiyowsnSBiDvYXFBLEPHnjhwlSIpMo"
            />
          </div>

          <div className="flex gap-3 pt-2">
            <button className="btn-primary">Save Changes</button>
            <button className="btn-alt">Cancel</button>
          </div>
        </div>
      </div>
    </div>
  )
}
