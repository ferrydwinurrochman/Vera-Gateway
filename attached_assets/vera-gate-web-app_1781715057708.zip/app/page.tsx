'use client'

import { redirect } from 'next/navigation'
import DashboardPage from './dashboard/page'

export default function Page() {
  return <DashboardPage />
}

